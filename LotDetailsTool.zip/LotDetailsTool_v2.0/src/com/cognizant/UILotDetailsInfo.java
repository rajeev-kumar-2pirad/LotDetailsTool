package com.cognizant;

import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;

import javax.swing.ImageIcon;
import javax.swing.JRadioButton;

public class UILotDetailsInfo extends JFrame {

	public static Connection conn;

	private JPanel contentPane;
	String country = null;
	String Lot_Number = null;

	private JTextField txtFld_DateOfLoss;
	private JTextField txtFld_recoveryDate;
	private JTextField txtFld_pickUpClearedDate;
	private JTextField txtFld_assignmentDate;
	private JTextField txtFld_chargeClearedDate;
	private JTextField txtFld_pickedUp;
	private JTextField txtFld_promisedPickup;
	private JTextField txtFld_originalTitleReceived;
	private JTextField txtFld_xferTitleReceived;
	private JTextField txtFld_submittedToDmv;
	private JTextField txtFld_titleReject;
	private JTextField txtFld_certReceived;
	private JTextField txtFld_sellerStgBillThru;
	private JTextField txtFld_lastSellerInvoice;
	private JTextField txtFld_lastPmtFromSeller;
	private JTextField txtFld_sellerSettlement;
	private JTextField txtFld_proceedsCut;
	private JTextField txtFld_sale;
	private JTextField txtFld_memberInvoice;
	private JTextField txtFld_memberStgBilledThr;
	private JTextField txtFld_memberFinalPaid;
	private JTextField txtFld_lotLeftYard;
	private JTextField txtFld_certSentToBuyer;
	private JTextField txtFld_eligibleForRelist;
	private JTextField txtFld_eligibleForLateFee;
	private JTextField txtFld_nicbReportedDate;

	private JRadioButton rdbtnBasicData;
	private JRadioButton rdbtnCriticalDates;
	private JRadioButton rdbtnSellerBillings;

	private JLabel lblLastSellerInvoice;
	private JLabel lblLastPymtFrom;
	private JLabel lblSellerSettlement;
	private JLabel lblProceedsCut;
	private JLabel lblSale;
	private JLabel lblMemberInvoice;
	private JLabel lblMemberStg;
	private JLabel lblMemberFinalPaid;
	private JLabel lblLotLeftYard;
	private JLabel lblCertSentTo;
	private JLabel lblEligibleForRelist;
	private JLabel lblEligibleForLate;
	private JLabel lblNICBReportedDate;
	private JLabel lblDateOfLoss;
	private JLabel lblRecoveryDate;
	private JLabel lblAssignmentDate;
	private JLabel lblPickUpClearedDate;
	private JLabel lblChargeClearedDate;
	private JLabel lblPickedUp;
	private JLabel lblPromisedPickUp;
	private JLabel lblOriginalTitleReceived;
	private JLabel lblXferTitleReceived;
	private JLabel lblSubmittedToDmv;
	private JLabel lblTitleReject;
	private JLabel lblCertReceived;
	private JLabel lblSellerStgBillThru;

	private JComboBox<String> comboBox;

	private JTextField txtFld_lotNoIp;
	private JTextField txtFld_lotNo;
	private JTextField txtFld_lotDesc;
	private JTextField txtFld_lotType;
	private JTextField txtFld_yard;
	private JTextField txtFld_minBidamt;
	private JTextField txtFld_vehicleType;
	private JTextField txtFld_primaryDamage;
	private JTextField txtFld_vin;
	private JTextField txtFld_odometer;
	private JTextField txtFld_keys;
	private JTextField txtFld_lotStage;
	private JTextField txtFld_saleDate;
	private JTextField txtFld_imageUpload;

	private JLabel lblLotNumber_1; 
	private JLabel lblLotDescription; 
	private JLabel lblYard; 
	private JLabel lblLotType; 
	private JLabel lblMinBidAmt; 
	private JLabel lblVehicleType; 
	private JLabel lblPrimaryDamage; 
	private JLabel lblVin; 
	private JLabel lblOdometer; 
	private JLabel lblKeys; 
	private JLabel lblLotStage; 
	private JLabel lblSaleDate; 
	private JLabel lblImageUpload; 
	private JLabel lblLotNumber; 
	private JLabel lblCountry;
	private JLabel lblCopartLogo;

	private JButton btnRetrieve; 


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UILotDetailsInfo frame = new UILotDetailsInfo();
					frame.setVisible(true);
					//frame.setAlwaysOnTop(true);
					frame.setLocationRelativeTo(null);
					GetConnectionThread thread=frame.new GetConnectionThread();
					thread.start();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	class GetConnectionThread extends Thread{
		public void run(){
			conn=LotDetailsInformation.getConnection();
			if(conn==null){
				String titleBar="VPN Issue";
				String message="Please check your VPN connection";
				Object infoMessage=message;
				JOptionPane.showMessageDialog(null, infoMessage, "Error Message: " + titleBar, JOptionPane.INFORMATION_MESSAGE); 
			}
		}
	}

	/**
	 * Create the frame.
	 */
	public UILotDetailsInfo() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(String.valueOf(System.getProperty("user.dir")) + "//icons//icon.png"));
		setResizable(false);
		setTitle("Lots Detail Information Tool");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 444);
		contentPane = new JPanel();
		contentPane.setForeground(Color.BLUE);
		contentPane.setBackground(new Color(0, 191, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblCopyrightByMember = new JLabel("Copyright By Member Team");
		lblCopyrightByMember.setFont(new Font("Calibri", Font.PLAIN, 11));
		lblCopyrightByMember.setBounds(460, 385, 128, 14);
		contentPane.add(lblCopyrightByMember);

		String pathName = null;
		pathName = String.valueOf(System.getProperty("user.dir")) + "//icons//images.png";

		JLabel lblFooterCountryImg = new JLabel("");
		pathName = String.valueOf(System.getProperty("user.dir")) + "//icons//countries.png";
		lblFooterCountryImg.setIcon(new ImageIcon(pathName));
		lblFooterCountryImg.setBounds(305, 400, 288, 14);
		contentPane.add(lblFooterCountryImg);

		JLabel lblAllDatesAre = new JLabel("*All dates are in mm/dd/yy format.");
		lblAllDatesAre.setBounds(30, 391, 261, 14);
		contentPane.add(lblAllDatesAre);

		rdbtnBasicData = new JRadioButton("Basic Data");
		rdbtnBasicData.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
				
				lblLastSellerInvoice.hide(); txtFld_lastSellerInvoice.hide(); txtFld_lastSellerInvoice.setText("");
				lblLastPymtFrom.hide(); txtFld_lastPmtFromSeller.hide(); txtFld_lastPmtFromSeller.setText("");
				lblSellerSettlement.hide(); txtFld_sellerSettlement.hide(); txtFld_sellerSettlement.setText("");
				lblProceedsCut.hide(); txtFld_proceedsCut.hide(); txtFld_proceedsCut.setText("");
				lblSale.hide(); txtFld_sale.hide(); txtFld_sale.setText("");
				lblMemberInvoice.hide(); txtFld_memberInvoice.hide(); txtFld_memberInvoice.setText("");
				lblMemberStg.hide(); txtFld_memberStgBilledThr.hide(); txtFld_memberStgBilledThr.setText("");
				lblMemberFinalPaid.hide(); txtFld_memberFinalPaid.hide(); txtFld_memberFinalPaid.setText("");
				lblLotLeftYard.hide(); txtFld_lotLeftYard.hide(); txtFld_lotLeftYard.setText("");
				lblCertSentTo.hide(); txtFld_certSentToBuyer.hide(); txtFld_certSentToBuyer.setText("");
				lblEligibleForRelist.hide(); txtFld_eligibleForRelist.hide(); txtFld_eligibleForRelist.setText("");
				lblEligibleForLate.hide(); txtFld_eligibleForLateFee.hide(); txtFld_eligibleForLateFee.setText("");
				lblNICBReportedDate.hide(); txtFld_nicbReportedDate.hide(); txtFld_nicbReportedDate.setText("");
				lblDateOfLoss.hide(); txtFld_DateOfLoss.hide(); txtFld_DateOfLoss.setText("");
				lblRecoveryDate.hide(); txtFld_recoveryDate.hide(); txtFld_recoveryDate.setText("");
				lblAssignmentDate.hide(); txtFld_assignmentDate.hide(); txtFld_assignmentDate.setText("");
				lblPickUpClearedDate.hide(); txtFld_pickUpClearedDate.hide(); txtFld_pickUpClearedDate.setText("");
				lblChargeClearedDate.hide(); txtFld_chargeClearedDate.hide(); txtFld_chargeClearedDate.setText("");
				lblPickedUp.hide(); txtFld_pickedUp.hide(); txtFld_pickedUp.setText("");
				lblPromisedPickUp.hide(); txtFld_promisedPickup.hide(); txtFld_promisedPickup.setText("");
				lblOriginalTitleReceived.hide(); txtFld_originalTitleReceived.hide(); txtFld_originalTitleReceived.setText("");
				lblXferTitleReceived.hide(); txtFld_xferTitleReceived.hide(); txtFld_xferTitleReceived.setText("");
				lblSubmittedToDmv.hide(); txtFld_submittedToDmv.hide(); txtFld_submittedToDmv.setText("");
				lblTitleReject.hide(); txtFld_titleReject.hide(); txtFld_titleReject.setText("");
				lblCertReceived.hide(); txtFld_certReceived.hide(); txtFld_certReceived.setText("");
				lblSellerStgBillThru.hide(); txtFld_sellerStgBillThru.hide(); txtFld_sellerStgBillThru.setText("");
				
			}
		});
		rdbtnBasicData.addMouseListener(new MouseAdapter() {
			@SuppressWarnings("deprecation")
			@Override
			public void mouseClicked(MouseEvent e) {
				
				lblLotNumber_1.show();  txtFld_lotNoIp.show();
				lblLotDescription.show(); txtFld_lotDesc.show();
				lblYard.show(); txtFld_yard.show();
				lblLotType.show();  txtFld_lotType.show();
				lblMinBidAmt.show(); txtFld_minBidamt.show();
				lblVehicleType.show(); txtFld_vehicleType.show();
				lblPrimaryDamage.show(); txtFld_primaryDamage.show();
				lblVin.show(); txtFld_vin.show();
				lblOdometer.show(); txtFld_odometer.show();
				lblKeys.show(); txtFld_keys.show();
				lblLotStage.show(); txtFld_lotStage.show();
				lblSaleDate.show(); txtFld_saleDate.show();
				lblImageUpload.show(); txtFld_imageUpload.show();
				lblLotNumber.show(); txtFld_lotNo.show();
				lblCountry.show(); comboBox.show();
				lblCopartLogo.show();
				btnRetrieve.show(); 
				
			}
		});

		rdbtnBasicData.setBackground(new Color(255, 0, 255));
		rdbtnBasicData.setFont(new Font("Calibri", Font.BOLD, 14));
		rdbtnBasicData.setBounds(30, 30, 110, 20);
		contentPane.add(rdbtnBasicData);

		rdbtnCriticalDates = new JRadioButton("Critical Dates");
		rdbtnCriticalDates.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {

				lblLotNumber_1.hide();  txtFld_lotNoIp.hide();
				lblLotDescription.hide(); txtFld_lotDesc.hide();
				lblYard.hide(); txtFld_yard.hide();
				lblLotType.hide();  txtFld_lotType.hide();
				lblMinBidAmt.hide(); txtFld_minBidamt.hide();
				lblVehicleType.hide(); txtFld_vehicleType.hide();
				lblPrimaryDamage.hide(); txtFld_primaryDamage.hide();
				lblVin.hide(); txtFld_vin.hide();
				lblOdometer.hide(); txtFld_odometer.hide();
				lblKeys.hide(); txtFld_keys.hide();
				lblLotStage.hide(); txtFld_lotStage.hide();
				lblSaleDate.hide(); txtFld_saleDate.hide();
				lblImageUpload.hide(); txtFld_imageUpload.hide();
				lblLotNumber.hide(); txtFld_lotNo.hide();
				lblCountry.hide(); comboBox.hide();
				lblCopartLogo.hide();
				btnRetrieve.hide(); 

			}
		});
		rdbtnCriticalDates.addMouseListener(new MouseAdapter() {
			@SuppressWarnings("deprecation")
			@Override
			public void mouseClicked(MouseEvent e) {

				lblLastSellerInvoice.show(); txtFld_lastSellerInvoice.show();
				lblLastPymtFrom.show(); txtFld_lastPmtFromSeller.show();
				lblSellerSettlement.show(); txtFld_sellerSettlement.show();
				lblProceedsCut.show(); txtFld_proceedsCut.show();
				lblSale.show(); txtFld_sale.show();
				lblMemberInvoice.show(); txtFld_memberInvoice.show();
				lblMemberStg.show(); txtFld_memberStgBilledThr.show();
				lblMemberFinalPaid.show(); txtFld_memberFinalPaid.show();
				lblLotLeftYard.show(); txtFld_lotLeftYard.show();
				lblCertSentTo.show(); txtFld_certSentToBuyer.show();
				lblEligibleForRelist.show(); txtFld_eligibleForRelist.show();
				lblEligibleForLate.show(); txtFld_eligibleForLateFee.show();
				lblNICBReportedDate.show(); txtFld_nicbReportedDate.show();
				lblDateOfLoss.show(); txtFld_DateOfLoss.show();
				lblRecoveryDate.show(); txtFld_recoveryDate.show();
				lblAssignmentDate.show(); txtFld_assignmentDate.show();
				lblPickUpClearedDate.show(); txtFld_pickUpClearedDate.show();
				lblChargeClearedDate.show(); txtFld_chargeClearedDate.show();
				lblPickedUp.show(); txtFld_pickedUp.show();
				lblPromisedPickUp.show(); txtFld_promisedPickup.show();
				lblOriginalTitleReceived.show(); txtFld_originalTitleReceived.show();
				lblXferTitleReceived.show(); txtFld_xferTitleReceived.show();
				lblSubmittedToDmv.show(); txtFld_submittedToDmv.show();
				lblTitleReject.show(); txtFld_titleReject.show();
				lblCertReceived.show(); txtFld_certReceived.show();
				lblSellerStgBillThru.show(); txtFld_sellerStgBillThru.show();

				String country=comboBox.getSelectedItem().toString();
				System.out.println(country);
				String lot_number_input=txtFld_lotNoIp.getText();
				System.out.println(lot_number_input);
				String lot_number_retrieved=txtFld_lotNo.getText();
				System.out.println(lot_number_retrieved);
				if(lot_number_input.equals("") || lot_number_input.equals(null)){
					JOptionPane.showMessageDialog(null,"<html><span style='color:blue'>Please Enter Lot Number To View Critical Dates.</span></html>","Info Message",JOptionPane.INFORMATION_MESSAGE);
				} else if(lot_number_input.equals(lot_number_retrieved)) {
					HashMap <String, String> hshLotInformation = new HashMap<String, String>();
					LotDetailsInformation obj=new LotDetailsInformation();
					try {
						hshLotInformation=obj.criticalDates(conn,country, lot_number_retrieved);
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					txtFld_DateOfLoss.setText(hshLotInformation.get("Date of Loss"));
					txtFld_DateOfLoss.setForeground(Color.BLUE);
					txtFld_DateOfLoss.setFont(new Font("Calibri", Font.BOLD, 14));
					txtFld_recoveryDate.setText(hshLotInformation.get("Date of Recovery"));
					txtFld_recoveryDate.setForeground(Color.BLUE);
					txtFld_recoveryDate.setFont(new Font("Calibri", Font.BOLD, 14));
					txtFld_pickUpClearedDate.setText(hshLotInformation.get("Pick Up Cleared Date"));
					txtFld_pickUpClearedDate.setForeground(Color.BLUE);
					txtFld_pickUpClearedDate.setFont(new Font("Calibri", Font.BOLD, 14));
					txtFld_assignmentDate.setText(hshLotInformation.get("Assignment Date"));
					txtFld_assignmentDate.setForeground(Color.BLUE);
					txtFld_assignmentDate.setFont(new Font("Calibri", Font.BOLD, 14));
					txtFld_chargeClearedDate.setText(hshLotInformation.get("Charge Cleared Date"));
					txtFld_chargeClearedDate.setForeground(Color.BLUE);
					txtFld_chargeClearedDate.setFont(new Font("Calibri", Font.BOLD, 14));
					txtFld_pickedUp.setText(hshLotInformation.get("Picked Up Date"));
					txtFld_pickedUp.setForeground(Color.BLUE);
					txtFld_pickedUp.setFont(new Font("Calibri", Font.BOLD, 14));
					txtFld_promisedPickup.setText(hshLotInformation.get("Promised PickUp Date"));
					txtFld_promisedPickup.setForeground(Color.BLUE);
					txtFld_promisedPickup.setFont(new Font("Calibri", Font.BOLD, 14));
					txtFld_originalTitleReceived.setText(hshLotInformation.get("Orginal Title Received Date"));
					txtFld_originalTitleReceived.setForeground(Color.BLUE);
					txtFld_originalTitleReceived.setFont(new Font("Calibri", Font.BOLD, 14));
					txtFld_xferTitleReceived.setText(hshLotInformation.get("Transferred Title Received Date"));
					txtFld_xferTitleReceived.setForeground(Color.BLUE);
					txtFld_xferTitleReceived.setFont(new Font("Calibri", Font.BOLD, 14));
					txtFld_submittedToDmv.setText(hshLotInformation.get("DMV title Submited Date"));
					txtFld_submittedToDmv.setForeground(Color.BLUE);
					txtFld_submittedToDmv.setFont(new Font("Calibri", Font.BOLD, 14));
					txtFld_titleReject.setText(hshLotInformation.get("DMV title Rejected Date"));
					txtFld_titleReject.setForeground(Color.BLUE);
					txtFld_titleReject.setFont(new Font("Calibri", Font.BOLD, 14));
					txtFld_certReceived.setText(hshLotInformation.get("Certificate Received Date"));
					txtFld_certReceived.setForeground(Color.BLUE);
					txtFld_certReceived.setFont(new Font("Calibri", Font.BOLD, 14));
					txtFld_sellerStgBillThru.setText(hshLotInformation.get("Seller Stg Bill Thru Date"));
					txtFld_sellerStgBillThru.setForeground(Color.BLUE);
					txtFld_sellerStgBillThru.setFont(new Font("Calibri", Font.BOLD, 14));
					txtFld_lastSellerInvoice.setText(hshLotInformation.get("Last Seller Invoice Date"));
					txtFld_lastSellerInvoice.setForeground(Color.BLUE);
					txtFld_lastSellerInvoice.setFont(new Font("Calibri", Font.BOLD, 14));
					txtFld_lastPmtFromSeller.setText(hshLotInformation.get("Last Pmt From Seller"));
					txtFld_lastPmtFromSeller.setForeground(Color.BLUE);
					txtFld_lastPmtFromSeller.setFont(new Font("Calibri", Font.BOLD, 14));
					txtFld_sellerSettlement.setText(hshLotInformation.get("Seller Settlement Date"));
					txtFld_sellerSettlement.setForeground(Color.BLUE);
					txtFld_sellerSettlement.setFont(new Font("Calibri", Font.BOLD, 14));
					txtFld_proceedsCut.setText(hshLotInformation.get("Proceeds Cut Date"));
					txtFld_proceedsCut.setForeground(Color.BLUE);
					txtFld_proceedsCut.setFont(new Font("Calibri", Font.BOLD, 14));
					txtFld_sale.setText(hshLotInformation.get("Sale Date"));
					txtFld_sale.setForeground(Color.BLUE);
					txtFld_sale.setFont(new Font("Calibri", Font.BOLD, 14));
					txtFld_memberInvoice.setText(hshLotInformation.get("Member Invoice Date"));
					txtFld_memberInvoice.setForeground(Color.BLUE);
					txtFld_memberInvoice.setFont(new Font("Calibri", Font.BOLD, 14));
					txtFld_memberStgBilledThr.setText(hshLotInformation.get("Member Stg Billed Date"));
					txtFld_memberStgBilledThr.setForeground(Color.BLUE);
					txtFld_memberStgBilledThr.setFont(new Font("Calibri", Font.BOLD, 14));
					txtFld_memberFinalPaid.setText(hshLotInformation.get("Member Final Paid"));
					txtFld_memberFinalPaid.setForeground(Color.BLUE);
					txtFld_memberFinalPaid.setFont(new Font("Calibri", Font.BOLD, 14));
					txtFld_lotLeftYard.setText(hshLotInformation.get("Lot Left Yard Date"));
					txtFld_lotLeftYard.setForeground(Color.BLUE);
					txtFld_lotLeftYard.setFont(new Font("Calibri", Font.BOLD, 14));
					txtFld_certSentToBuyer.setText(hshLotInformation.get("Cert Sent To Buyer Date"));
					txtFld_certSentToBuyer.setForeground(Color.BLUE);
					txtFld_certSentToBuyer.setFont(new Font("Calibri", Font.BOLD, 14));
					txtFld_eligibleForRelist.setText(hshLotInformation.get("Eligible For Relist Date"));
					txtFld_eligibleForRelist.setForeground(Color.BLUE);
					txtFld_eligibleForRelist.setFont(new Font("Calibri", Font.BOLD, 14));
					txtFld_eligibleForLateFee.setText(hshLotInformation.get("Eligible For Late Fee Date"));
					txtFld_eligibleForLateFee.setForeground(Color.BLUE);
					txtFld_eligibleForLateFee.setFont(new Font("Calibri", Font.BOLD, 14));
					txtFld_nicbReportedDate.setText(hshLotInformation.get("NICB Reported Date"));
					txtFld_nicbReportedDate.setForeground(Color.BLUE);
					txtFld_nicbReportedDate.setFont(new Font("Calibri", Font.BOLD, 14));
				}else{
					JOptionPane.showMessageDialog(null,"<html><span style='color:red'>After Entering Lot No, Please Enter RETRIEVE Button.</span></html>","Warning Message",JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		rdbtnCriticalDates.setFont(new Font("Calibri", Font.BOLD, 14));
		rdbtnCriticalDates.setBackground(Color.MAGENTA);
		rdbtnCriticalDates.setBounds(163, 30, 110, 20);
		contentPane.add(rdbtnCriticalDates);

		rdbtnSellerBillings = new JRadioButton("Seller Billings");
		rdbtnSellerBillings.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {

				lblLastSellerInvoice.hide(); txtFld_lastSellerInvoice.hide();
				lblLastPymtFrom.hide(); txtFld_lastPmtFromSeller.hide();
				lblSellerSettlement.hide(); txtFld_sellerSettlement.hide();
				lblProceedsCut.hide(); txtFld_proceedsCut.hide();
				lblSale.hide(); txtFld_sale.hide();
				lblMemberInvoice.hide(); txtFld_memberInvoice.hide();
				lblMemberStg.hide(); txtFld_memberStgBilledThr.hide();
				lblMemberFinalPaid.hide(); txtFld_memberFinalPaid.hide();
				lblLotLeftYard.hide(); txtFld_lotLeftYard.hide();
				lblCertSentTo.hide(); txtFld_certSentToBuyer.hide();
				lblEligibleForRelist.hide(); txtFld_eligibleForRelist.hide();
				lblEligibleForLate.hide(); txtFld_eligibleForLateFee.hide();
				lblNICBReportedDate.hide(); txtFld_nicbReportedDate.hide();
				lblDateOfLoss.hide(); txtFld_DateOfLoss.hide();
				lblRecoveryDate.hide(); txtFld_recoveryDate.hide();
				lblAssignmentDate.hide(); txtFld_assignmentDate.hide();
				lblPickUpClearedDate.hide(); txtFld_pickUpClearedDate.hide();
				lblChargeClearedDate.hide(); txtFld_chargeClearedDate.hide();
				lblPickedUp.hide(); txtFld_pickedUp.hide();
				lblPromisedPickUp.hide(); txtFld_promisedPickup.hide();
				lblOriginalTitleReceived.hide(); txtFld_originalTitleReceived.hide();
				lblXferTitleReceived.hide(); txtFld_xferTitleReceived.hide();
				lblSubmittedToDmv.hide(); txtFld_submittedToDmv.hide();
				lblTitleReject.hide(); txtFld_titleReject.hide();
				lblCertReceived.hide(); txtFld_certReceived.hide();
				lblSellerStgBillThru.hide(); txtFld_sellerStgBillThru.hide();

			}
		});
		rdbtnSellerBillings.addMouseListener(new MouseAdapter() {
			@SuppressWarnings("deprecation")
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		rdbtnSellerBillings.setFont(new Font("Calibri", Font.BOLD, 14));
		rdbtnSellerBillings.setBackground(Color.MAGENTA);
		rdbtnSellerBillings.setBounds(296, 30, 110, 20);
		contentPane.add(rdbtnSellerBillings);

		ButtonGroup bg=new ButtonGroup();
		bg.add(rdbtnBasicData);
		rdbtnBasicData.setSelected(true);
		bg.add(rdbtnCriticalDates);
		bg.add(rdbtnSellerBillings);

		//if(rdbtnCriticalDates.isSelected()){

		lblDateOfLoss = new JLabel("Date of Loss");
		lblDateOfLoss.setVisible(false);
		lblDateOfLoss.setFont(new Font("Calibri", Font.BOLD, 14));
		lblDateOfLoss.setBounds(30, 60, 130, 20);
		contentPane.add(lblDateOfLoss);

		lblRecoveryDate = new JLabel("Recovery Date");
		lblRecoveryDate.setVisible(false);
		lblRecoveryDate.setFont(new Font("Calibri", Font.BOLD, 14));
		lblRecoveryDate.setBounds(30, 85, 130, 20);
		contentPane.add(lblRecoveryDate);

		lblAssignmentDate = new JLabel("Assignment Date");
		lblAssignmentDate.setVisible(false);
		lblAssignmentDate.setFont(new Font("Calibri", Font.BOLD, 14));
		lblAssignmentDate.setBounds(30, 110, 130, 20);
		contentPane.add(lblAssignmentDate);

		lblPickUpClearedDate = new JLabel("PickUp Cleared Date");
		lblPickUpClearedDate.setVisible(false);
		lblPickUpClearedDate.setFont(new Font("Calibri", Font.BOLD, 14));
		lblPickUpClearedDate.setBounds(30, 135, 130, 20);
		contentPane.add(lblPickUpClearedDate);

		lblChargeClearedDate = new JLabel("Charge Cleared Date");
		lblChargeClearedDate.setVisible(false);
		lblChargeClearedDate.setFont(new Font("Calibri", Font.BOLD, 14));
		lblChargeClearedDate.setBounds(30, 160, 130, 20);
		contentPane.add(lblChargeClearedDate);

		lblPickedUp = new JLabel("Picked Up");
		lblPickedUp.setVisible(false);
		lblPickedUp.setFont(new Font("Calibri", Font.BOLD, 14));
		lblPickedUp.setBounds(30, 185, 130, 20);
		contentPane.add(lblPickedUp);

		lblPromisedPickUp = new JLabel("Promised PickUp");
		lblPromisedPickUp.setVisible(false);
		lblPromisedPickUp.setFont(new Font("Calibri", Font.BOLD, 14));
		lblPromisedPickUp.setBounds(30, 210, 130, 20);
		contentPane.add(lblPromisedPickUp);

		lblOriginalTitleReceived = new JLabel("Original Title Received");
		lblOriginalTitleReceived.setVisible(false);
		lblOriginalTitleReceived.setFont(new Font("Calibri", Font.BOLD, 14));
		lblOriginalTitleReceived.setBounds(30, 235, 130, 20);
		contentPane.add(lblOriginalTitleReceived);

		lblXferTitleReceived = new JLabel("XFER Title Received");
		lblXferTitleReceived.setVisible(false);
		lblXferTitleReceived.setFont(new Font("Calibri", Font.BOLD, 14));
		lblXferTitleReceived.setBounds(30, 260, 130, 20);
		contentPane.add(lblXferTitleReceived);

		lblSubmittedToDmv = new JLabel("Submitted to DMV");
		lblSubmittedToDmv.setVisible(false);
		lblSubmittedToDmv.setFont(new Font("Calibri", Font.BOLD, 14));
		lblSubmittedToDmv.setBounds(30, 285, 130, 20);
		contentPane.add(lblSubmittedToDmv);

		lblTitleReject = new JLabel("Title Reject");
		lblTitleReject.setVisible(false);
		lblTitleReject.setFont(new Font("Calibri", Font.BOLD, 14));
		lblTitleReject.setBounds(30, 310, 130, 20);
		contentPane.add(lblTitleReject);

		lblCertReceived = new JLabel("Cert. Received");
		lblCertReceived.setVisible(false);
		lblCertReceived.setFont(new Font("Calibri", Font.BOLD, 14));
		lblCertReceived.setBounds(30, 335, 130, 20);
		contentPane.add(lblCertReceived);

		lblSellerStgBillThru = new JLabel("Seller Stg Bill Thru");
		lblSellerStgBillThru.setVisible(false);
		lblSellerStgBillThru.setFont(new Font("Calibri", Font.BOLD, 14));
		lblSellerStgBillThru.setBounds(30, 360, 130, 20);
		contentPane.add(lblSellerStgBillThru);

		txtFld_DateOfLoss = new JTextField();
		txtFld_DateOfLoss.setVisible(false);
		txtFld_DateOfLoss.setForeground(new Color(0, 0, 255));
		txtFld_DateOfLoss.setFont(new Font("Calibri", Font.BOLD, 14));
		txtFld_DateOfLoss.setEditable(false);
		txtFld_DateOfLoss.setBounds(163, 60, 100, 20);
		contentPane.add(txtFld_DateOfLoss);
		txtFld_DateOfLoss.setColumns(10);

		txtFld_recoveryDate = new JTextField();
		txtFld_recoveryDate.setVisible(false);
		txtFld_recoveryDate.setForeground(new Color(0, 0, 255));
		txtFld_recoveryDate.setFont(new Font("Calibri", Font.BOLD, 14));
		txtFld_recoveryDate.setEditable(false);
		txtFld_recoveryDate.setColumns(10);
		txtFld_recoveryDate.setBounds(163, 85, 100, 20);
		contentPane.add(txtFld_recoveryDate);

		txtFld_pickUpClearedDate = new JTextField();
		txtFld_pickUpClearedDate.setVisible(false);
		txtFld_pickUpClearedDate.setFont(new Font("Calibri", Font.BOLD, 14));
		txtFld_pickUpClearedDate.setForeground(new Color(0, 0, 255));
		txtFld_pickUpClearedDate.setEditable(false);
		txtFld_pickUpClearedDate.setColumns(10);
		txtFld_pickUpClearedDate.setBounds(163, 135, 100, 20);
		contentPane.add(txtFld_pickUpClearedDate);

		txtFld_assignmentDate = new JTextField();
		txtFld_assignmentDate.setVisible(false);
		txtFld_assignmentDate.setFont(new Font("Calibri", Font.BOLD, 14));
		txtFld_assignmentDate.setForeground(new Color(0, 0, 255));
		txtFld_assignmentDate.setEditable(false);
		txtFld_assignmentDate.setColumns(10);
		txtFld_assignmentDate.setBounds(163, 110, 100, 20);
		contentPane.add(txtFld_assignmentDate);

		txtFld_chargeClearedDate = new JTextField();
		txtFld_chargeClearedDate.setVisible(false);
		txtFld_chargeClearedDate.setForeground(new Color(0, 0, 255));
		txtFld_chargeClearedDate.setFont(new Font("Calibri", Font.BOLD, 14));
		txtFld_chargeClearedDate.setEditable(false);
		txtFld_chargeClearedDate.setColumns(10);
		txtFld_chargeClearedDate.setBounds(163, 160, 100, 20);
		contentPane.add(txtFld_chargeClearedDate);

		txtFld_pickedUp = new JTextField();
		txtFld_pickedUp.setVisible(false);
		txtFld_pickedUp.setForeground(new Color(0, 0, 255));
		txtFld_pickedUp.setFont(new Font("Calibri", Font.BOLD, 14));
		txtFld_pickedUp.setEditable(false);
		txtFld_pickedUp.setColumns(10);
		txtFld_pickedUp.setBounds(163, 185, 100, 20);
		contentPane.add(txtFld_pickedUp);

		txtFld_promisedPickup = new JTextField();
		txtFld_promisedPickup.setVisible(false);
		txtFld_promisedPickup.setForeground(new Color(0, 0, 255));
		txtFld_promisedPickup.setFont(new Font("Calibri", Font.BOLD, 14));
		txtFld_promisedPickup.setEditable(false);
		txtFld_promisedPickup.setColumns(10);
		txtFld_promisedPickup.setBounds(163, 210, 100, 20);
		contentPane.add(txtFld_promisedPickup);

		txtFld_originalTitleReceived = new JTextField();
		txtFld_originalTitleReceived.setVisible(false);
		txtFld_originalTitleReceived.setFont(new Font("Calibri", Font.BOLD, 14));
		txtFld_originalTitleReceived.setForeground(new Color(0, 0, 255));
		txtFld_originalTitleReceived.setEditable(false);
		txtFld_originalTitleReceived.setColumns(10);
		txtFld_originalTitleReceived.setBounds(163, 235, 100, 20);
		contentPane.add(txtFld_originalTitleReceived);

		txtFld_xferTitleReceived = new JTextField();
		txtFld_xferTitleReceived.setVisible(false);
		txtFld_xferTitleReceived.setForeground(new Color(0, 0, 255));
		txtFld_xferTitleReceived.setFont(new Font("Calibri", Font.BOLD, 14));
		txtFld_xferTitleReceived.setEditable(false);
		txtFld_xferTitleReceived.setColumns(10);
		txtFld_xferTitleReceived.setBounds(163, 260, 100, 20);
		contentPane.add(txtFld_xferTitleReceived);

		txtFld_submittedToDmv = new JTextField();
		txtFld_submittedToDmv.setVisible(false);
		txtFld_submittedToDmv.setFont(new Font("Calibri", Font.BOLD, 14));
		txtFld_submittedToDmv.setForeground(new Color(0, 0, 255));
		txtFld_submittedToDmv.setEditable(false);
		txtFld_submittedToDmv.setColumns(10);
		txtFld_submittedToDmv.setBounds(163, 285, 100, 20);
		contentPane.add(txtFld_submittedToDmv);

		txtFld_titleReject = new JTextField();
		txtFld_titleReject.setVisible(false);
		txtFld_titleReject.setFont(new Font("Calibri", Font.BOLD, 14));
		txtFld_titleReject.setForeground(new Color(0, 0, 255));
		txtFld_titleReject.setEditable(false);
		txtFld_titleReject.setColumns(10);
		txtFld_titleReject.setBounds(163, 310, 100, 20);
		contentPane.add(txtFld_titleReject);

		txtFld_certReceived = new JTextField();
		txtFld_certReceived.setVisible(false);
		txtFld_certReceived.setForeground(new Color(0, 0, 255));
		txtFld_certReceived.setFont(new Font("Calibri", Font.BOLD, 14));
		txtFld_certReceived.setEditable(false);
		txtFld_certReceived.setColumns(10);
		txtFld_certReceived.setBounds(163, 335, 100, 20);
		contentPane.add(txtFld_certReceived);

		txtFld_sellerStgBillThru = new JTextField();
		txtFld_sellerStgBillThru.setVisible(false);
		txtFld_sellerStgBillThru.setFont(new Font("Calibri", Font.BOLD, 14));
		txtFld_sellerStgBillThru.setForeground(new Color(0, 0, 255));
		txtFld_sellerStgBillThru.setEditable(false);
		txtFld_sellerStgBillThru.setColumns(10);
		txtFld_sellerStgBillThru.setBounds(163, 360, 100, 20);
		contentPane.add(txtFld_sellerStgBillThru);

		lblLastSellerInvoice = new JLabel("Last Seller Invoice");
		lblLastSellerInvoice.setVisible(false);
		lblLastSellerInvoice.setFont(new Font("Calibri", Font.BOLD, 14));
		lblLastSellerInvoice.setBounds(325, 60, 130, 20);
		contentPane.add(lblLastSellerInvoice);

		lblLastPymtFrom = new JLabel("Last Pmt from Seller");
		lblLastPymtFrom.setVisible(false);
		lblLastPymtFrom.setFont(new Font("Calibri", Font.BOLD, 14));
		lblLastPymtFrom.setBounds(325, 85, 130, 20);
		contentPane.add(lblLastPymtFrom);

		lblSellerSettlement = new JLabel("Seller Settlement");
		lblSellerSettlement.setVisible(false);
		lblSellerSettlement.setFont(new Font("Calibri", Font.BOLD, 14));
		lblSellerSettlement.setBounds(325, 110, 130, 20);
		contentPane.add(lblSellerSettlement);

		lblProceedsCut = new JLabel("Proceeds Cut");
		lblProceedsCut.setVisible(false);
		lblProceedsCut.setFont(new Font("Calibri", Font.BOLD, 14));
		lblProceedsCut.setBounds(325, 135, 130, 20);
		contentPane.add(lblProceedsCut);

		lblSale = new JLabel("Sale");
		lblSale.setVisible(false);
		lblSale.setFont(new Font("Calibri", Font.BOLD, 14));
		lblSale.setBounds(325, 160, 130, 20);
		contentPane.add(lblSale);

		lblMemberInvoice = new JLabel("Member Invoice");
		lblMemberInvoice.setVisible(false);
		lblMemberInvoice.setFont(new Font("Calibri", Font.BOLD, 14));
		lblMemberInvoice.setBounds(325, 185, 130, 20);
		contentPane.add(lblMemberInvoice);

		lblMemberStg = new JLabel("Member Stg Billed Thr");
		lblMemberStg.setVisible(false);
		lblMemberStg.setFont(new Font("Calibri", Font.BOLD, 14));
		lblMemberStg.setBounds(325, 210, 130, 20);
		contentPane.add(lblMemberStg);

		lblMemberFinalPaid = new JLabel("Member Final Paid");
		lblMemberFinalPaid.setVisible(false);
		lblMemberFinalPaid.setFont(new Font("Calibri", Font.BOLD, 14));
		lblMemberFinalPaid.setBounds(325, 235, 130, 20);
		contentPane.add(lblMemberFinalPaid);

		lblLotLeftYard = new JLabel("Lot Left Yard");
		lblLotLeftYard.setVisible(false);
		lblLotLeftYard.setFont(new Font("Calibri", Font.BOLD, 14));
		lblLotLeftYard.setBounds(325, 260, 130, 20);
		contentPane.add(lblLotLeftYard);

		lblCertSentTo = new JLabel("Cert. Sent To Buyer");
		lblCertSentTo.setVisible(false);
		lblCertSentTo.setFont(new Font("Calibri", Font.BOLD, 14));
		lblCertSentTo.setBounds(325, 285, 130, 20);
		contentPane.add(lblCertSentTo);

		lblEligibleForRelist = new JLabel("Eligible for Relist");
		lblEligibleForRelist.setVisible(false);
		lblEligibleForRelist.setFont(new Font("Calibri", Font.BOLD, 14));
		lblEligibleForRelist.setBounds(325, 310, 130, 20);
		contentPane.add(lblEligibleForRelist);

		lblEligibleForLate = new JLabel("Eligible for Late Fee");
		lblEligibleForLate.setVisible(false);
		lblEligibleForLate.setFont(new Font("Calibri", Font.BOLD, 14));
		lblEligibleForLate.setBounds(325, 335, 130, 20);
		contentPane.add(lblEligibleForLate);

		lblNICBReportedDate = new JLabel("NICB Reported Date");
		lblNICBReportedDate.setVisible(false);
		lblNICBReportedDate.setFont(new Font("Calibri", Font.BOLD, 14));
		lblNICBReportedDate.setBounds(325, 360, 130, 20);
		contentPane.add(lblNICBReportedDate);

		txtFld_lastSellerInvoice = new JTextField();
		txtFld_lastSellerInvoice.setVisible(false);
		txtFld_lastSellerInvoice.setFont(new Font("Calibri", Font.BOLD, 14));
		txtFld_lastSellerInvoice.setForeground(new Color(0, 0, 255));
		txtFld_lastSellerInvoice.setEditable(false);
		txtFld_lastSellerInvoice.setColumns(10);
		txtFld_lastSellerInvoice.setBounds(455, 60, 100, 20);
		contentPane.add(txtFld_lastSellerInvoice);

		txtFld_lastPmtFromSeller = new JTextField();
		txtFld_lastPmtFromSeller.setVisible(false);
		txtFld_lastPmtFromSeller.setFont(new Font("Calibri", Font.BOLD, 14));
		txtFld_lastPmtFromSeller.setForeground(new Color(0, 0, 255));
		txtFld_lastPmtFromSeller.setEditable(false);
		txtFld_lastPmtFromSeller.setColumns(10);
		txtFld_lastPmtFromSeller.setBounds(455, 85, 100, 20);
		contentPane.add(txtFld_lastPmtFromSeller);

		txtFld_sellerSettlement = new JTextField();
		txtFld_sellerSettlement.setVisible(false);
		txtFld_sellerSettlement.setFont(new Font("Calibri", Font.BOLD, 14));
		txtFld_sellerSettlement.setEditable(false);
		txtFld_sellerSettlement.setColumns(10);
		txtFld_sellerSettlement.setBounds(455, 110, 100, 20);
		contentPane.add(txtFld_sellerSettlement);

		txtFld_proceedsCut = new JTextField();
		txtFld_proceedsCut.setVisible(false);
		txtFld_proceedsCut.setForeground(new Color(0, 0, 255));
		txtFld_proceedsCut.setFont(new Font("Calibri", Font.BOLD, 14));
		txtFld_proceedsCut.setEditable(false);
		txtFld_proceedsCut.setColumns(10);
		txtFld_proceedsCut.setBounds(455, 135, 100, 20);
		contentPane.add(txtFld_proceedsCut);

		txtFld_sale = new JTextField();
		txtFld_sale.setVisible(false);
		txtFld_sale.setForeground(new Color(0, 0, 255));
		txtFld_sale.setFont(new Font("Calibri", Font.BOLD, 14));
		txtFld_sale.setEditable(false);
		txtFld_sale.setColumns(10);
		txtFld_sale.setBounds(455, 160, 100, 20);
		contentPane.add(txtFld_sale);

		txtFld_memberInvoice = new JTextField();
		txtFld_memberInvoice.setVisible(false);
		txtFld_memberInvoice.setForeground(new Color(0, 0, 255));
		txtFld_memberInvoice.setFont(new Font("Calibri", Font.BOLD, 14));
		txtFld_memberInvoice.setEditable(false);
		txtFld_memberInvoice.setColumns(10);
		txtFld_memberInvoice.setBounds(455, 185, 100, 20);
		contentPane.add(txtFld_memberInvoice);

		txtFld_memberStgBilledThr = new JTextField();
		txtFld_memberStgBilledThr.setVisible(false);
		txtFld_memberStgBilledThr.setFont(new Font("Calibri", Font.BOLD, 14));
		txtFld_memberStgBilledThr.setForeground(new Color(0, 0, 255));
		txtFld_memberStgBilledThr.setEditable(false);
		txtFld_memberStgBilledThr.setColumns(10);
		txtFld_memberStgBilledThr.setBounds(455, 210, 100, 20);
		contentPane.add(txtFld_memberStgBilledThr);

		txtFld_memberFinalPaid = new JTextField();
		txtFld_memberFinalPaid.setVisible(false);
		txtFld_memberFinalPaid.setForeground(new Color(0, 0, 255));
		txtFld_memberFinalPaid.setFont(new Font("Calibri", Font.BOLD, 14));
		txtFld_memberFinalPaid.setEditable(false);
		txtFld_memberFinalPaid.setColumns(10);
		txtFld_memberFinalPaid.setBounds(455, 235, 100, 20);
		contentPane.add(txtFld_memberFinalPaid);

		txtFld_lotLeftYard = new JTextField();
		txtFld_lotLeftYard.setVisible(false);
		txtFld_lotLeftYard.setFont(new Font("Calibri", Font.BOLD, 14));
		txtFld_lotLeftYard.setForeground(new Color(0, 0, 255));
		txtFld_lotLeftYard.setEditable(false);
		txtFld_lotLeftYard.setColumns(10);
		txtFld_lotLeftYard.setBounds(455, 260, 100, 20);
		contentPane.add(txtFld_lotLeftYard);

		txtFld_certSentToBuyer = new JTextField();
		txtFld_certSentToBuyer.setVisible(false);
		txtFld_certSentToBuyer.setFont(new Font("Calibri", Font.BOLD, 14));
		txtFld_certSentToBuyer.setForeground(new Color(0, 0, 255));
		txtFld_certSentToBuyer.setEditable(false);
		txtFld_certSentToBuyer.setColumns(10);
		txtFld_certSentToBuyer.setBounds(455, 285, 100, 20);
		contentPane.add(txtFld_certSentToBuyer);

		txtFld_eligibleForRelist = new JTextField();
		txtFld_eligibleForRelist.setVisible(false);
		txtFld_eligibleForRelist.setFont(new Font("Calibri", Font.BOLD, 14));
		txtFld_eligibleForRelist.setForeground(new Color(0, 0, 255));
		txtFld_eligibleForRelist.setEditable(false);
		txtFld_eligibleForRelist.setColumns(10);
		txtFld_eligibleForRelist.setBounds(455, 310, 100, 20);
		contentPane.add(txtFld_eligibleForRelist);

		txtFld_eligibleForLateFee = new JTextField();
		txtFld_eligibleForLateFee.setVisible(false);
		txtFld_eligibleForLateFee.setForeground(new Color(0, 0, 255));
		txtFld_eligibleForLateFee.setFont(new Font("Calibri", Font.BOLD, 14));
		txtFld_eligibleForLateFee.setEditable(false);
		txtFld_eligibleForLateFee.setColumns(10);
		txtFld_eligibleForLateFee.setBounds(455, 335, 100, 20);
		contentPane.add(txtFld_eligibleForLateFee);

		txtFld_nicbReportedDate = new JTextField();
		txtFld_nicbReportedDate.setVisible(false);
		txtFld_nicbReportedDate.setFont(new Font("Calibri", Font.BOLD, 14));
		txtFld_nicbReportedDate.setForeground(new Color(0, 0, 255));
		txtFld_nicbReportedDate.setEditable(false);
		txtFld_nicbReportedDate.setColumns(10);
		txtFld_nicbReportedDate.setBounds(455, 360, 100, 20);
		contentPane.add(txtFld_nicbReportedDate);

		//}

		//if(rdbtnBasicData.isSelected()){

		lblCopartLogo = new JLabel("");
		pathName = String.valueOf(System.getProperty("user.dir")) + "//icons//images.png";
		lblCopartLogo.setIcon(new ImageIcon(pathName));
		lblCopartLogo.setBounds(375, 70, 181, 89);
		contentPane.add(lblCopartLogo);

		lblCountry = new JLabel("Country");
		lblCountry.setFont(new Font("Calibri", Font.BOLD, 14));
		lblCountry.setBounds(375, 177, 48, 17);
		contentPane.add(lblCountry);

		comboBox = new JComboBox(new String[] {"US/CT", "UK/IRE/MEA", "Other"});
		comboBox.setEditable(true);
		comboBox.setBounds(440, 175, 100, 20);
		comboBox.setPreferredSize(new Dimension(200, 20));
		comboBox.addItemListener(e -> {
			Object selectedItem = comboBox.getSelectedItem();
			boolean editable = selectedItem instanceof String
					&& ((String) selectedItem).equals("Other");
			comboBox.setEditable(editable);
		});
		comboBox.getEditor().addActionListener(e -> {
			Object newItem = comboBox.getEditor().getItem();
			DefaultComboBoxModel d = (DefaultComboBoxModel) comboBox.getModel();
			d.addElement(newItem);
			d.setSelectedItem(newItem);
		});
		contentPane.add(comboBox);

		lblLotNumber = new JLabel("Lot No.");
		lblLotNumber.setFont(new Font("Calibri", Font.BOLD, 14));
		lblLotNumber.setBounds(375, 207, 43, 17);
		contentPane.add(lblLotNumber);

		txtFld_lotNoIp = new JTextField();
		txtFld_lotNoIp.setForeground(new Color(0, 0, 0));
		txtFld_lotNoIp.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//textField.setText("");
				txtFld_lotNo.setText("");
				txtFld_lotDesc.setText("");
				txtFld_yard.setText("");
				txtFld_lotType.setText("");
				txtFld_minBidamt.setText("");
				txtFld_vehicleType.setText("");
				txtFld_primaryDamage.setText("");
				txtFld_vin.setText("");
				txtFld_odometer.setText("");
				txtFld_keys.setText("");
				txtFld_lotStage.setText("");
				txtFld_saleDate.setText("");
				txtFld_imageUpload.setText("");
			}
		});
		
		txtFld_lotNoIp.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e) {
				int key = e.getKeyCode();
				if (key == KeyEvent.VK_ENTER) {
					Toolkit.getDefaultToolkit().beep();   
					System.out.println("ENTER pressed");
					JOptionPane.showMessageDialog(null,"<html><span style='color:red'>Please click RETRIEVE button.</span></html>","Warning Message",JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		
		txtFld_lotNoIp.setBounds(440, 205, 100, 20);
		contentPane.add(txtFld_lotNoIp);
		txtFld_lotNoIp.setColumns(10);

		btnRetrieve = new JButton("RETRIEVE");
		btnRetrieve.setForeground(Color.BLACK);
		btnRetrieve.setBackground(new Color(50, 205, 50));
		btnRetrieve.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				btnRetrieve.setText("PLEASE WAIT");
				btnRetrieve.setForeground(new Color(255, 0, 0));
				btnRetrieve.setBackground(new Color(60, 179, 113)); // Not working
				btnRetrieve.setFont(new Font("Calibri", Font.BOLD, 14));
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				String country=comboBox.getSelectedItem().toString();
				System.out.println(country);
				String lot_number_input=txtFld_lotNoIp.getText();
				System.out.println(lot_number_input);
				HashMap <String, String> hshLotInformation = new HashMap<String, String>();
				LotDetailsInformation obj=new LotDetailsInformation();
				try {
					if(lot_number_input.equals("") || lot_number_input.equals(null)){
						JOptionPane.showMessageDialog(null,"<html><span style='color:red'>Lot No field can't be blank.</span></html>","Error Message",JOptionPane.ERROR_MESSAGE);
					} else {
						hshLotInformation=obj.basicInfo(conn,country, lot_number_input);
						txtFld_lotNo.setText(hshLotInformation.get("Lot Number"));
						txtFld_lotNo.setForeground(Color.BLUE);
						txtFld_lotNo.setFont(new Font("Calibri", Font.BOLD, 14));
						txtFld_lotDesc.setText(hshLotInformation.get("Lot Description"));
						txtFld_lotDesc.setForeground(Color.BLUE);
						txtFld_lotDesc.setFont(new Font("Calibri", Font.BOLD, 14));
						txtFld_yard.setText(hshLotInformation.get("Yard_Seller"));
						txtFld_yard.setForeground(Color.BLUE);
						txtFld_yard.setFont(new Font("Calibri", Font.BOLD, 14));
						txtFld_lotType.setText(hshLotInformation.get("Lot Type"));
						txtFld_lotType.setForeground(Color.BLUE);
						txtFld_lotType.setFont(new Font("Calibri", Font.BOLD, 14));
						txtFld_minBidamt.setText(hshLotInformation.get("Min Bid Amt"));
						txtFld_minBidamt.setForeground(Color.BLUE);
						txtFld_minBidamt.setFont(new Font("Calibri", Font.BOLD, 14));
						txtFld_vehicleType.setText(hshLotInformation.get("Vehicle Type"));
						txtFld_vehicleType.setForeground(Color.BLUE);
						txtFld_vehicleType.setFont(new Font("Calibri", Font.BOLD, 14));
						txtFld_primaryDamage.setText(hshLotInformation.get("Primary Damage"));
						txtFld_primaryDamage.setForeground(Color.BLUE);
						txtFld_primaryDamage.setFont(new Font("Calibri", Font.BOLD, 14));
						txtFld_vin.setText(hshLotInformation.get("VIN"));
						txtFld_vin.setForeground(Color.BLUE);
						txtFld_vin.setFont(new Font("Calibri", Font.BOLD, 14));
						txtFld_odometer.setText(hshLotInformation.get("Odometer"));
						txtFld_odometer.setForeground(Color.BLUE);
						txtFld_odometer.setFont(new Font("Calibri", Font.BOLD, 14));
						txtFld_keys.setText(hshLotInformation.get("Keys"));
						txtFld_keys.setForeground(Color.BLUE);
						txtFld_keys.setFont(new Font("Calibri", Font.BOLD, 14));
						txtFld_lotStage.setText(hshLotInformation.get("Lot Stage"));
						txtFld_lotStage.setForeground(Color.BLUE);
						txtFld_lotStage.setFont(new Font("Calibri", Font.BOLD, 14));
						txtFld_saleDate.setText(hshLotInformation.get("Sale Date(mm/dd/yy)"));
						txtFld_saleDate.setForeground(Color.BLUE);
						txtFld_saleDate.setFont(new Font("Calibri", Font.BOLD, 14));
						txtFld_imageUpload.setText(hshLotInformation.get("Image Upload"));
						txtFld_imageUpload.setForeground(Color.BLUE);
						txtFld_imageUpload.setFont(new Font("Calibri", Font.BOLD, 14));


					}
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					//e1.printStackTrace();
					System.out.println(e1.getMessage());
					JOptionPane.showMessageDialog(null,"<html><span style='color:red'>"+e1.getMessage()+"</span></html>","Error Message",JOptionPane.WARNING_MESSAGE);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					//e1.printStackTrace();
					System.out.println(e1.getMessage());
					JOptionPane.showMessageDialog(null,"<html><span style='color:red'>"+e1.getMessage()+"</span></html>","Error Message",JOptionPane.WARNING_MESSAGE);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					System.out.println(e1.getMessage());
					JOptionPane.showMessageDialog(null,"<html><span style='color:red'>"+e1.getMessage()+"</span></html>","Error Message",JOptionPane.WARNING_MESSAGE);
				}
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				btnRetrieve.setText("RETRIEVE");
				btnRetrieve.setForeground(Color.BLACK);
				btnRetrieve.setBackground(new Color(50, 205, 50));
				btnRetrieve.setFont(new Font("Calibri", Font.BOLD, 14));
			}
		});

		btnRetrieve.setFont(new Font("Calibri", Font.BOLD, 14));
		btnRetrieve.setBounds(425, 240, 115, 25);
		contentPane.add(btnRetrieve);

		lblLotNumber_1 = new JLabel("Lot No");
		lblLotNumber_1.setFont(new Font("Calibri", Font.BOLD, 14));
		lblLotNumber_1.setBounds(30, 60, 80, 20);
		contentPane.add(lblLotNumber_1);

		lblLotDescription = new JLabel("Lot Desc");
		lblLotDescription.setFont(new Font("Calibri", Font.BOLD, 14));
		lblLotDescription.setBounds(30, 85, 80, 20);
		contentPane.add(lblLotDescription);

		lblYard = new JLabel("Yard/Seller");
		lblYard.setFont(new Font("Calibri", Font.BOLD, 14));
		lblYard.setBounds(30, 110, 80, 20);
		contentPane.add(lblYard);

		lblLotType = new JLabel("Lot Type");
		lblLotType.setFont(new Font("Calibri", Font.BOLD, 14));
		lblLotType.setBounds(30, 135, 80, 20);
		contentPane.add(lblLotType);

		lblMinBidAmt = new JLabel("Min Bid Amt");
		lblMinBidAmt.setFont(new Font("Calibri", Font.BOLD, 14));
		lblMinBidAmt.setBounds(30, 160, 80, 20);
		contentPane.add(lblMinBidAmt);

		lblVehicleType = new JLabel("Vehicle Type");
		lblVehicleType.setFont(new Font("Calibri", Font.BOLD, 14));
		lblVehicleType.setBounds(30, 185, 80, 20);
		contentPane.add(lblVehicleType);

		lblPrimaryDamage = new JLabel("Primary Dmg");
		lblPrimaryDamage.setFont(new Font("Calibri", Font.BOLD, 14));
		lblPrimaryDamage.setBounds(30, 210, 80, 20);
		contentPane.add(lblPrimaryDamage);

		lblVin = new JLabel("VIN");
		lblVin.setFont(new Font("Calibri", Font.BOLD, 14));
		lblVin.setBounds(30, 235, 80, 20);
		contentPane.add(lblVin);

		lblOdometer = new JLabel("Odometer");
		lblOdometer.setFont(new Font("Calibri", Font.BOLD, 14));
		lblOdometer.setBounds(30, 260, 80, 20);
		contentPane.add(lblOdometer);

		lblKeys = new JLabel("Keys");
		lblKeys.setFont(new Font("Calibri", Font.BOLD, 14));
		lblKeys.setBounds(30, 285, 80, 20);
		contentPane.add(lblKeys);

		lblLotStage = new JLabel("Lot Stage");
		lblLotStage.setFont(new Font("Calibri", Font.BOLD, 14));
		lblLotStage.setBounds(30, 310, 80, 20);
		contentPane.add(lblLotStage);

		lblSaleDate = new JLabel("Sale Date");
		lblSaleDate.setFont(new Font("Calibri", Font.BOLD, 14));
		lblSaleDate.setBounds(30, 335, 80, 20);
		contentPane.add(lblSaleDate);

		lblImageUpload = new JLabel("Img Upload");
		lblImageUpload.setFont(new Font("Calibri", Font.BOLD, 14));
		lblImageUpload.setBounds(30, 360, 90, 20);
		contentPane.add(lblImageUpload);

		txtFld_lotNo = new JTextField();
		txtFld_lotNo.setEditable(false);
		txtFld_lotNo.setBounds(110, 60, 230, 20);
		contentPane.add(txtFld_lotNo);
		txtFld_lotNo.setColumns(10);

		txtFld_lotDesc = new JTextField();
		txtFld_lotDesc.setEditable(false);
		txtFld_lotDesc.setColumns(10);
		txtFld_lotDesc.setBounds(110, 85, 230, 20);
		contentPane.add(txtFld_lotDesc);

		txtFld_lotType = new JTextField();
		txtFld_lotType.setEditable(false);
		txtFld_lotType.setColumns(10);
		txtFld_lotType.setBounds(110, 135, 230, 20);
		contentPane.add(txtFld_lotType);

		txtFld_yard = new JTextField();
		txtFld_yard.setEditable(false);
		txtFld_yard.setColumns(10);
		txtFld_yard.setBounds(110, 110, 230, 20);
		contentPane.add(txtFld_yard);

		txtFld_minBidamt = new JTextField();
		txtFld_minBidamt.setEditable(false);
		txtFld_minBidamt.setColumns(10);
		txtFld_minBidamt.setBounds(110, 160, 230, 20);
		contentPane.add(txtFld_minBidamt);

		txtFld_vehicleType = new JTextField();
		txtFld_vehicleType.setEditable(false);
		txtFld_vehicleType.setColumns(10);
		txtFld_vehicleType.setBounds(110, 185, 230, 20);
		contentPane.add(txtFld_vehicleType);

		txtFld_primaryDamage = new JTextField();
		txtFld_primaryDamage.setEditable(false);
		txtFld_primaryDamage.setColumns(10);
		txtFld_primaryDamage.setBounds(110, 210, 230, 20);
		contentPane.add(txtFld_primaryDamage);

		txtFld_vin = new JTextField();
		txtFld_vin.setEditable(false);
		txtFld_vin.setColumns(10);
		txtFld_vin.setBounds(110, 235, 230, 20);
		contentPane.add(txtFld_vin);

		txtFld_odometer = new JTextField();
		txtFld_odometer.setEditable(false);
		txtFld_odometer.setColumns(10);
		txtFld_odometer.setBounds(110, 260, 230, 20);
		contentPane.add(txtFld_odometer);

		txtFld_keys = new JTextField();
		txtFld_keys.setEditable(false);
		txtFld_keys.setColumns(10);
		txtFld_keys.setBounds(110, 285, 230, 20);
		contentPane.add(txtFld_keys);

		txtFld_lotStage = new JTextField();
		txtFld_lotStage.setEditable(false);
		txtFld_lotStage.setColumns(10);
		txtFld_lotStage.setBounds(110, 310, 230, 20);
		contentPane.add(txtFld_lotStage);

		txtFld_saleDate = new JTextField();
		txtFld_saleDate.setEditable(false);
		txtFld_saleDate.setColumns(10);
		txtFld_saleDate.setBounds(110, 335, 230, 20);
		contentPane.add(txtFld_saleDate);

		txtFld_imageUpload = new JTextField();
		txtFld_imageUpload.setEditable(false);
		txtFld_imageUpload.setColumns(10);
		txtFld_imageUpload.setBounds(110, 360, 230, 20);
		contentPane.add(txtFld_imageUpload);

		//}

	}
}
