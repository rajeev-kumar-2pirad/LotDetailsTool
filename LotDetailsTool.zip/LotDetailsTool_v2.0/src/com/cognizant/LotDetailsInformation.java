package com.cognizant;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Properties;

import javax.swing.JOptionPane;

public class LotDetailsInformation {

	public static void main(String[] args) throws IOException, SQLException, ClassNotFoundException {

		Connection conn=getConnection();
		LotDetailsInformation ldi = new LotDetailsInformation();
		//ldi.basicInfo(conn,"us","49990656");
		ldi.criticalDates(conn, "US", "49990656");
	}

	public static Connection getConnection(){
		Connection conn=null;
		String pathname = String.valueOf(System.getProperty("user.dir")) + "//supportLibraries//dbUtility.properties";
		File file = new File(pathname);
		Properties prop = new Properties();
		FileInputStream input = null;
		try {
			input = new FileInputStream(file);
			prop.load(input);
			String JDBC_DRIVER = prop.getProperty("JDBC_DRIVER");
			String DB_URL = prop.getProperty("DB_URL");
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL, prop.getProperty("Username"), prop.getProperty("Password"));
			System.out.println(".....Connected to database.....");
			System.out.println("Connection Established Successfull and the DATABASE name is:" + conn.getMetaData().getDatabaseProductName());
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		return conn;
	}


	public HashMap<String, String> basicInfo(Connection conn,String country,String lot_number) throws IOException, SQLException, ClassNotFoundException {
		HashMap <String, String> hshLotInformation = new HashMap<String, String>();
		String key = "";
		String value = "";

		try{
			Statement stm = conn.createStatement();
			ResultSet rs = null;
			if (country.contains("UK") || country.contains("MEA") || country.contains("IRE") || country.contains("uk") || country.contains("mea") || country.contains("ire") || country.equalsIgnoreCase("IE") || country.equalsIgnoreCase("IRELAND") || country.equalsIgnoreCase("MIDDLE EAST")) {
				rs = stm.executeQuery("Select LTLOTNBR,LTLOTCEN,LTLOTYER,LTLOTMAK,LTLOTMDL,LTLOTCLR,LTYRDNBR,LTSLRNBR,LTSVGTYP,LTDMGTYP,LTVINNBR,LTMINBID,LTAPRBID,LTODRRCV,LTHASKYS,LTLOTSTG,LTAUCDDD,LTAUCMMM,LTAUCYYY from GBRPRDDB.LOTLT where LTLOTNBR= " + lot_number);
			}else if(country.contains("US") || country.contains("CT") || country.contains("us") || country.contains("ct") || country.contains("CRASHEDTOYS")) {
				rs = stm.executeQuery("Select LTLOTNBR,LTLOTCEN,LTLOTYER,LTLOTMAK,LTLOTMDL,LTLOTCLR,LTYRDNBR,LTSLRNBR,LTSVGTYP,LTDMGTYP,LTVINNBR,LTMINBID,LTAPRBID,LTODRRCV,LTHASKYS,LTLOTSTG,LTAUCDDD,LTAUCMMM,LTAUCYYY from MISPRDDB.LOTLT where LTLOTNBR= " + lot_number);
			}else{
				JOptionPane.showMessageDialog(null,"<html><span style='color:red'>Either entered country is not valid or<br>Query isn't available for this country</br></span></html>","Error Message",JOptionPane.WARNING_MESSAGE);
			}

			String lot_Nbr = ""; 
			String lot_Year = "";
			String lot_Century = ""; 
			String lot_Make = ""; 
			String lot_Model = ""; 
			String lot_Color = ""; 
			String yard_Nbr = ""; 
			String seller_Nm= "";
			String veh_Type = "";
			String pry_Dmg = ""; 
			String vin_Nbr = ""; 
			String min_Bid = ""; 
			String flag_BTBA = ""; 
			String odometer = ""; 
			String flag_Keys = ""; 
			String lot_Stage = ""; 
			String sale_Day = ""; 
			String sale_Month = ""; 
			String sale_Year = "";  
			String img_Upload_Count="";

			// Read and Handle the result set
			while (rs.next()) {
				lot_Nbr = rs.getString("LTLOTNBR").trim();
				lot_Century = rs.getString("LTLOTCEN").trim();
				lot_Year = rs.getString("LTLOTYER").trim();
				lot_Make = rs.getString("LTLOTMAK").trim();
				lot_Model = rs.getString("LTLOTMDL").trim();
				lot_Color = rs.getString("LTLOTCLR").trim();
				yard_Nbr = rs.getString("LTYRDNBR").trim();
				seller_Nm = rs.getString("LTSLRNBR").trim();
				veh_Type = rs.getString("LTSVGTYP").trim();
				pry_Dmg = rs.getString("LTDMGTYP").trim();
				vin_Nbr = rs.getString("LTVINNBR").trim();
				min_Bid = rs.getString("LTMINBID").trim();  
				flag_BTBA = rs.getString("LTAPRBID").trim();
				odometer = rs.getString("LTODRRCV").trim();
				flag_Keys = rs.getString("LTHASKYS").trim();
				lot_Stage = rs.getString("LTLOTSTG").trim();
				sale_Day = rs.getString("LTAUCDDD").trim();
				sale_Month = rs.getString("LTAUCMMM").trim();
				sale_Year = rs.getString("LTAUCYYY").trim(); 
			}

			rs = stm.executeQuery("Select COUNT(IQCOD1UD)/2 AS IMGCOUNT from COPDTA.IMGMSTIQ where IQLOTNBR= " + lot_number);
			while (rs.next()) {
				img_Upload_Count=rs.getString("IMGCOUNT").trim();
			}
			System.out.println(img_Upload_Count);

			// close the connection 
			// conn.close();
			// System.out.println(".....Closed the connection!.....");

			String sale_Date = sale_Month + "/" + sale_Day + "/" + sale_Year;
			
			String yard_Seller = yard_Nbr + " ::: " + seller_Nm;

			if(Integer.parseInt(lot_Year)<10){
				lot_Year = "0" + lot_Year;
			}
			String lot_Desc = lot_Century + lot_Year + " :: " + lot_Make + " :: " + lot_Model + " :: " + lot_Color;

			String lot_Type=null;
			if(flag_BTBA.equalsIgnoreCase("Y")){
				lot_Type= "BTBA";
			}else{
				Double bid_Amt=Double.parseDouble(min_Bid);
				if(bid_Amt==0){
					lot_Type="Pure Sale";
				}else{
					lot_Type="Minimum Bid";
				}
			}


			String[] arrVehicleType = {"A - ATV","C - MOTORCYCLE","D - DIRT BIKE","E - INDUSTRIAL EQUIPMENT","H - OTHER GOODS","I - INSPECTION","J - JETSKI","K - MEDIUM DUTY/BOX TRUCKS","L - TRAILERS","M - BOAT","R - RECREATIONAL VEHICLE(RV)","S - SNOWMOBILE","T- TRANSPORT","U - HEAVY DUTY TRUCKS","V - AUTOMOBILE"};
			for(String str:arrVehicleType){
				//System.out.println(str+":::"+veh_Type);
				if(str.startsWith(veh_Type)){
					veh_Type=str;
				}
			}

			String[] arrPrimaryDamageType = {"AO - ALL OVER","BC - BIOHAZARD/CHEMICAL","BE - BURN ENGINE","BI - BURN INTERIOR","BN - BURN","CC - CASH FOR CLUNKERS","DH - DAMAGE HISTORY","DU - DRIVETRAIN UNK/UNABLE TO VERIFY","FD - FRAME DAMAGE","FR - FRONT END","HL - HAIL","MC - MECHANICAL","MN - MINOR DENT/SCRATCHES","NK - NO KEYS","NW - NORMAL WEAR","PR - PARTIAL REPAIR","RJ - REJECTED REPAIR","RO - ROLLOVER","RR - REAR END","SD - SIDE","ST - STRIPPED","TP - TOP/ROOF","UK - UNKNOWN","UN - UNDERCARRIAGE","VI - MISSING/ALTERED VIN","VN - VANDALISM","VP - REPLACED VIN","WA - WATER/FLOOD"   };
			for(String str:arrPrimaryDamageType){
				//System.out.println(str+":::"+pry_Dmg);
				if(str.startsWith(pry_Dmg)){
					pry_Dmg=str;
				}
			}

			if(flag_Keys.equals("Y")){
				flag_Keys="YES";
			}else if(flag_Keys.equals("N")){
				flag_Keys="NO";
			}

			String[] arrLotStage = {"10 - WAITING TO CLEAR PICKUP","20 - WAITING FOR DRIVER DISPATCH","25 - WAITING FOR ADVANCE CHECK","28 - WAITING FOR TRIP CONFIRMATION","30 - WAITING FOR INVENTORY/BILLING","40 - AWAITING TITLE FROM STATE","50 - READY FOR AUCTION","60 - AWAITING BID APPROVAL","70 - WAITING FOR BUYER PAYMENT","80 - WAITING TO CUT SELLER CHECK","90 - WAITING FOR SELLER PAYMENT","99 - CLOSED"};
			for(String str:arrLotStage){
				//System.out.println(str+":::"+lot_Stage);
				if(str.startsWith(lot_Stage)){
					lot_Stage=str;
				}
			}

			if(Integer.parseInt(img_Upload_Count) != 0){
				img_Upload_Count = "YES" + " ::: Image Count = " + img_Upload_Count;
			}else{
				img_Upload_Count = "NO";
			}

			String[] lotAttribute = {"Lot Number","Lot Description","Yard_Seller","Lot Type","Min Bid Amt","Vehicle Type","Primary Damage","VIN","Odometer","Keys","Lot Stage","Sale Date(mm/dd/yy)","Image Upload"};
			String[] lotValue = {lot_Nbr,lot_Desc,yard_Seller,lot_Type,min_Bid,veh_Type,pry_Dmg,vin_Nbr,odometer,flag_Keys,lot_Stage,sale_Date,img_Upload_Count};

			for(int i=0; i< lotAttribute.length; i++)
			{
				key = lotAttribute[i];
				value = lotValue[i];
				hshLotInformation.put(key, value);
				System.out.println(key+" ::: "+value);
			}
			//System.out.println(hshLotInformation);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
			if(e.getMessage().contains("DAY INF NAN NOT RID ROW")){
				JOptionPane.showMessageDialog(null,"<html><span style='color:red'>Lot number is required.</span></html>","Error Message",JOptionPane.ERROR_MESSAGE);
			}else if(e.getMessage().contains("For input string: \"\"") || e.getMessage().equals(null)){
				JOptionPane.showMessageDialog(null,"<html><span style='color:red'>Either Lot no longer exists or invalid lot number is entered.</span></html>","Error Message",JOptionPane.ERROR_MESSAGE);
			}else if(e.getMessage().contains("The application requester cannot establish the connection.")){
				JOptionPane.showMessageDialog(null,"<html><span style='color:red'>"+e.getMessage()+"</span><br><span style='color:blue'>Please check your VPN connection.</br></span></html>","Error Message",JOptionPane.ERROR_MESSAGE);
			}else{
				JOptionPane.showMessageDialog(null,"<html><span style='color:red'>"+e.getMessage()+"</span></html>","Error Message",JOptionPane.ERROR_MESSAGE);
			}
		}

		return hshLotInformation;
	}

	public HashMap<String, String> criticalDates(Connection conn,String country,String lot_number) throws IOException, SQLException, ClassNotFoundException {
		HashMap <String, String> hshLotInformation = new HashMap<String, String>();
		String key = "";
		String value = "";

		try{
			Statement stm = conn.createStatement();
			ResultSet rs = null;
			if (country.contains("UK") || country.contains("MEA") || country.contains("IRE") || country.contains("uk") || country.contains("mea") || country.contains("ire") || country.equalsIgnoreCase("IE") || country.equalsIgnoreCase("IRELAND") || country.equalsIgnoreCase("MIDDLE EAST")) {
				rs = stm.executeQuery("Select LTLOSMMM,LTLOSDDD,LTLOSYYY,LTLOSCCC,LTRVYMMM,LTRVYDDD,LTRVYYYY,LTRVYCCC,LTASGMMM,LTASGDDD,LTASGYYY,LTASGCCC,LTPUCMMM,LTPUCDDD,LTPUCYYY,LTPUCCCC,LTCGCMMM,LTCGCDDD,LTCGCYYY,LTCGCCCC,LTPUPMMM,LTPUPDDD,LTPUPYYY,LTPUPCCC,LTPPUMMM,LTPPUDDD,LTPPUYYY,LTPPUCCC,LTOTLMMM,LTOTLDDD,LTOTLYYY,LTOTLCCC,LTXTLMMM,LTXTLDDD,LTXTLYYY,LTXTLCCC,LTSTLMMM,LTSTLDDD,LTSTLYYY,LTSTLCCC,LTRTLMMM,LTRTLDDD,LTRTLYYY,LTRTLCCC,LTCRCMMM,LTCRCDDD,LTCRCYYY,LTCRCCCC,LTNICMMM,LTNICDDD,LTNICYYY,LTNICCCC from GBRPRDDB.LOTLT where LTLOTNBR= " + lot_number);
			}else if(country.contains("US") || country.contains("CT") || country.contains("us") || country.contains("ct") || country.contains("CRASHEDTOYS")) {
				rs = stm.executeQuery("Select LTLOSMMM,LTLOSDDD,LTLOSYYY,LTLOSCCC,LTRVYMMM,LTRVYDDD,LTRVYYYY,LTRVYCCC,LTASGMMM,LTASGDDD,LTASGYYY,LTASGCCC,LTPUCMMM,LTPUCDDD,LTPUCYYY,LTPUCCCC,LTCGCMMM,LTCGCDDD,LTCGCYYY,LTCGCCCC,LTPUPMMM,LTPUPDDD,LTPUPYYY,LTPUPCCC,LTPPUMMM,LTPPUDDD,LTPPUYYY,LTPPUCCC,LTOTLMMM,LTOTLDDD,LTOTLYYY,LTOTLCCC,LTXTLMMM,LTXTLDDD,LTXTLYYY,LTXTLCCC,LTSTLMMM,LTSTLDDD,LTSTLYYY,LTSTLCCC,LTRTLMMM,LTRTLDDD,LTRTLYYY,LTRTLCCC,LTCRCMMM,LTCRCDDD,LTCRCYYY,LTCRCCCC,LTNICMMM,LTNICDDD,LTNICYYY,LTNICCCC from MISPRDDB.LOTLT where LTLOTNBR =" + lot_number);
			}else{
				JOptionPane.showMessageDialog(null,"<html><span style='color:red'>Either entered country is not valid or<br>Query isn't available for this country</br></span></html>","Error Message",JOptionPane.WARNING_MESSAGE);
			}

			String dateOfLoss = ""; 
			String dateOfRecovery = "";
			String assignmentDate = ""; 
			String pickUpClearedDate = ""; 
			String chargeClearedDate = ""; 
			String pickedUp = ""; 
			String promisedPickUp = ""; 
			String orginalTitleReceived = "";
			String xferTitleReceived = ""; 
			String submitedToDMV = ""; 
			String titleReject = ""; 
			String certReceived = ""; 
			String sellerStgBillThru = ""; 
			String lastSellerInvoice = ""; 
			String lstPmtFromSeller = "";  
			String sellerSettlement="";
			String proceedsCut="";
			String sale="";
			String memberInvoice="";
			String memberStgBilled="";
			String memberFinalPaid="";
			String lotLeftYard="";
			String certSentToBuyer="";
			String eligibleForRelist="";
			String eligibleForLateFee="";
			String nicbReportedDate="";

			// Read and Handle the result set
			while (rs.next()) {
				dateOfLoss = rs.getString("LTLOSMMM").trim()+"/"+rs.getString("LTLOSDDD").trim()+"/"+rs.getString("LTLOSYYY").trim();
				dateOfRecovery = rs.getString("LTRVYMMM").trim()+"/"+rs.getString("LTRVYDDD").trim()+"/"+rs.getString("LTRVYYYY").trim();
				assignmentDate = rs.getString("LTASGMMM").trim()+"/"+rs.getString("LTASGDDD").trim()+"/"+rs.getString("LTASGYYY").trim();
				pickUpClearedDate = rs.getString("LTPUCMMM").trim()+"/"+rs.getString("LTPUCDDD").trim()+"/"+rs.getString("LTPUCYYY").trim();
				chargeClearedDate = rs.getString("LTCGCMMM").trim()+"/"+rs.getString("LTCGCDDD").trim()+"/"+rs.getString("LTCGCYYY").trim();
				pickedUp = rs.getString("LTPUPMMM").trim()+"/"+rs.getString("LTPUPDDD").trim()+"/"+rs.getString("LTPUPYYY").trim();
				promisedPickUp = rs.getString("LTPPUMMM").trim()+"/"+rs.getString("LTPPUDDD").trim()+"/"+rs.getString("LTPPUYYY").trim();
				orginalTitleReceived = rs.getString("LTOTLMMM").trim()+"/"+rs.getString("LTOTLDDD").trim()+"/"+rs.getString("LTOTLYYY").trim();
				xferTitleReceived = rs.getString("LTXTLMMM").trim()+"/"+rs.getString("LTXTLDDD").trim()+"/"+rs.getString("LTXTLYYY").trim();
				submitedToDMV = rs.getString("LTSTLMMM").trim()+"/"+rs.getString("LTSTLDDD").trim()+"/"+rs.getString("LTSTLYYY").trim();
				titleReject = rs.getString("LTRTLMMM").trim()+"/"+rs.getString("LTRTLDDD").trim()+"/"+rs.getString("LTRTLYYY").trim();
				certReceived = rs.getString("LTCRCMMM").trim()+"/"+rs.getString("LTCRCDDD").trim()+"/"+rs.getString("LTCRCYYY").trim();
				nicbReportedDate = rs.getString("LTNICMMM").trim()+"/"+rs.getString("LTNICDDD").trim()+"/"+rs.getString("LTNICYYY").trim();
			}
			System.out.println("Date of Loss ::: "+ dateOfLoss);
			System.out.println("Date of Recovery ::: "+ dateOfRecovery);
			System.out.println("Assignment Date ::: "+ assignmentDate);
			System.out.println("Pick Up Cleared Date ::: "+ pickUpClearedDate);
			System.out.println("Charge Cleared Date ::: "+ chargeClearedDate);
			System.out.println("Picked Up Date ::: "+ pickedUp);
			System.out.println("Promised PickUp Date ::: "+ promisedPickUp);
			System.out.println("Orginal Title Received Date ::: "+ orginalTitleReceived);
			System.out.println("Transferred Title Received Date ::: "+ xferTitleReceived);
			System.out.println("DMV title Submited Date ::: "+ submitedToDMV);
			System.out.println("DMV title Rejected Date ::: "+ titleReject);
			System.out.println("Certificate Received Date ::: "+ certReceived);
			System.out.println("NICB Reported Date ::: "+ nicbReportedDate);

			if (country.contains("UK") || country.contains("MEA") || country.contains("IRE") || country.contains("uk") || country.contains("mea") || country.contains("ire") || country.equalsIgnoreCase("IE") || country.equalsIgnoreCase("IRELAND") || country.equalsIgnoreCase("MIDDLE EAST")) {
				rs = stm.executeQuery("Select LBSCSMMM,LBSCSDDD,LBSCSYYY,LBSCSCCC,LBINVMMM,LBINVDDD,LBINVYYY,LBINVCCC,LBLBSMMM,LBLBSDDD,LBLBSYYY,LBLBSCCC,LBSETMMM,LBSETDDD,LBSETYYY,LBSETCCC,LBLLYMMM,LBLLYDDD,LBLLYYYY,LBLLYCCC,LBRELMMM,LBRELDDD,LBRELYYY,LBRELCCC,LBLCGMMM,LBLCGDDD,LBLCGYYY,LBLCGCCC from GBRPRDDB.LOTLT where LBLOTNBR= " + lot_number);
			}else if(country.contains("US") || country.contains("CT") || country.contains("us") || country.contains("ct") || country.contains("CRASHEDTOYS")) {
				rs = stm.executeQuery("Select LBSCSMMM,LBSCSDDD,LBSCSYYY,LBSCSCCC,LBINVMMM,LBINVDDD,LBINVYYY,LBINVCCC,LBLBSMMM,LBLBSDDD,LBLBSYYY,LBLBSCCC,LBSETMMM,LBSETDDD,LBSETYYY,LBSETCCC,LBLLYMMM,LBLLYDDD,LBLLYYYY,LBLLYCCC,LBRELMMM,LBRELDDD,LBRELYYY,LBRELCCC,LBLCGMMM,LBLCGDDD,LBLCGYYY,LBLCGCCC from MISPRDDB.LOTBILLB where LBLOTNBR =" + lot_number);
			}else{
				JOptionPane.showMessageDialog(null,"<html><span style='color:red'>Either entered country is not valid or<br>Query isn't available for this country</br></span></html>","Error Message",JOptionPane.WARNING_MESSAGE);
			}
			while (rs.next()) {
				sellerStgBillThru = rs.getString("LBSCSMMM").trim()+"/"+rs.getString("LBSCSDDD").trim()+"/"+rs.getString("LBSCSYYY").trim();
				//lastSellerInvoice = rs.getString("LBINVMMM").trim()+"/"+rs.getString("LBINVDDD").trim()+"/"+rs.getString("LBINVYYY").trim();
				//lstPmtFromSeller = rs.getString("LBLBSMMM").trim()+"/"+rs.getString("LBLBSDDD").trim()+"/"+rs.getString("LBLBSYYY").trim();
				sellerSettlement = rs.getString("LBSETMMM").trim()+"/"+rs.getString("LBSETDDD").trim()+"/"+rs.getString("LBSETYYY").trim();
				lotLeftYard = rs.getString("LBLLYMMM").trim()+"/"+rs.getString("LBLLYDDD").trim()+"/"+rs.getString("LBLLYYYY").trim();
				eligibleForRelist = rs.getString("LBRELMMM").trim()+"/"+rs.getString("LBRELDDD").trim()+"/"+rs.getString("LBRELYYY").trim();
				eligibleForLateFee = rs.getString("LBLCGMMM").trim()+"/"+rs.getString("LBLCGDDD").trim()+"/"+rs.getString("LBLCGYYY").trim();
			}
			System.out.println("Seller Stg Bill Thru ::: "+ sellerStgBillThru);
			//System.out.println("Last Seller Invoice Date ::: "+ lastSellerInvoice);
			//System.out.println("Last Payment From Seller Date ::: "+ lstPmtFromSeller);
			System.out.println("Seller Settlement Date ::: "+ sellerSettlement);
			System.out.println("Lot Left Yard Date ::: "+ lotLeftYard);
			System.out.println("Eligible For Relist Date ::: "+ eligibleForRelist);
			System.out.println("Eligible For Late Fee Date ::: "+ eligibleForLateFee);

			// close the connection 
			// conn.close();
			// System.out.println(".....Closed the connection!.....");

			/*
			String sale_Date = sale_Month + "/" + sale_Day + "/" + sale_Year;

			if(Integer.parseInt(lot_Year)<10){
				lot_Year = "0" + lot_Year;
			}
			String lot_Desc = lot_Century + lot_Year + " :: " + lot_Make + " :: " + lot_Model + " :: " + lot_Color;
			 */
			String[] lotAttribute = {"Date of Loss","Date of Recovery","Assignment Date","Pick Up Cleared Date","Charge Cleared Date","Picked Up Date","Promised PickUp Date","Orginal Title Received Date","Transferred Title Received Date","DMV title Submited Date","DMV title Rejected Date","Certificate Received Date","Seller Stg Bill Thru Date","Last Seller Invoice Date","Last Pmt From Seller","Seller Settlement Date","Proceeds Cut Date","Sale Date","Member Invoice Date","Member Stg Billed Date","Member Final Paid","Lot Left Yard Date","Cert Sent To Buyer Date","Eligible For Relist Date","Eligible For Late Fee Date","NICB Reported Date"};
			String[] lotValue = {dateOfLoss,dateOfRecovery,assignmentDate,pickUpClearedDate,chargeClearedDate,pickedUp,promisedPickUp,orginalTitleReceived,xferTitleReceived,submitedToDMV,titleReject,certReceived,sellerStgBillThru,lastSellerInvoice,lstPmtFromSeller,sellerSettlement,proceedsCut,sale,memberInvoice,memberStgBilled,memberFinalPaid,lotLeftYard,certSentToBuyer,eligibleForRelist,eligibleForLateFee,nicbReportedDate};
			System.out.println("******************************************************");
			for(int i=0; i< lotAttribute.length; i++)
			{
				key = lotAttribute[i];
				value = lotValue[i];
				hshLotInformation.put(key, value);
				System.out.println(key+" ::: "+value);
			}

			//System.out.println(hshLotInformation);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
			if(e.getMessage().contains("DAY INF NAN NOT RID ROW")){
				JOptionPane.showMessageDialog(null,"<html><span style='color:red'>Lot number is required.</span></html>","Error Message",JOptionPane.ERROR_MESSAGE);
			}else if(e.getMessage().contains("For input string: \"\"") || e.getMessage().equals(null)){
				JOptionPane.showMessageDialog(null,"<html><span style='color:red'>Either Lot no longer exists or invalid lot number is entered.</span></html>","Error Message",JOptionPane.ERROR_MESSAGE);
			}else if(e.getMessage().contains("The application requester cannot establish the connection.")){
				JOptionPane.showMessageDialog(null,"<html><span style='color:red'>"+e.getMessage()+"</span><br><span style='color:blue'>Please check your VPN connection.</br></span></html>","Error Message",JOptionPane.ERROR_MESSAGE);
			}else{
				JOptionPane.showMessageDialog(null,"<html><span style='color:red'>"+e.getMessage()+"</span></html>","Error Message",JOptionPane.ERROR_MESSAGE);
			}
		}

		return hshLotInformation;
	}
}